import './App.css';
import Header from './Components/Header';
import Navbar from './Components/Navbar';
import ProductList from './Components/Products';

function App() {
  return (
    <div>
      <Header />
      <Navbar />
      <ProductList />
    </div>
  );
}

export default App;
