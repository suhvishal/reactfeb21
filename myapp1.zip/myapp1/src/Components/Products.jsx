import React, { Component } from 'react';

class ProductList extends Component {
    
    render() {
        return (
            <div style={ProductListStyle}>
               <h1>This is Products Component</h1> 
            </div>
        );
    }
}

const ProductListStyle = {
    background : 'lightyellow',
    padding: '10px',
    height : '600px'
}

export default ProductList;