//rsf    //rsc 

import React from 'react';

const Header = () => {
    return (
        <div className='header'>
            <h1>This is Header</h1>
        </div>
    );
};

export default Header;
