import React from 'react';
import './Product.css'

const Product = () => {
    return (
        <div>
            
        </div>
    );
};

export default Product;